"""IAudit - Utility functions."""
