"""IAudit - Empresa Detail Page."""

import streamlit as st
import httpx
import pandas as pd
import os

st.set_page_config(page_title="IAudit — Detalhes", page_icon="🔍", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")


def fetch(endpoint: str, params: dict | None = None):
    try:
        r = httpx.get(f"{BACKEND_URL}{endpoint}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return None


def put(endpoint: str, json_data: dict):
    try:
        r = httpx.put(f"{BACKEND_URL}{endpoint}", json=json_data, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro: {e}")
        return None


def post(endpoint: str, json_data: dict | None = None):
    try:
        r = httpx.post(f"{BACKEND_URL}{endpoint}", json=json_data, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro: {e}")
        return None


# ─── Header ──────────────────────────────────────────────────────────
st.markdown("""
<div style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
            padding: 1.5rem 2rem; border-radius: 12px; margin-bottom: 1.5rem;
            border: 1px solid #1e3a5f;">
    <h1 style="color: #60a5fa; margin: 0; font-size: 1.8rem;">🔍 Detalhes da Empresa</h1>
    <p style="color: #94a3b8; margin: 0.3rem 0 0 0;">Histórico e configurações individualizado</p>
</div>
""", unsafe_allow_html=True)

# ─── Select Empresa ──────────────────────────────────────────────────
empresas = fetch("/api/empresas", {"limit": 500})

if not empresas:
    st.info("Nenhuma empresa cadastrada.")
    st.stop()

# Check if coming from Empresas page
pre_selected = st.session_state.get("detail_empresa_id")

empresa_options = [(e["id"], f"{e['razao_social']} ({e['cnpj']})") for e in empresas]
default_idx = 0
if pre_selected:
    for i, (eid, _) in enumerate(empresa_options):
        if eid == pre_selected:
            default_idx = i
            break

selected = st.selectbox(
    "Selecione a Empresa",
    options=empresa_options,
    index=default_idx,
    format_func=lambda x: x[1],
)

if not selected:
    st.stop()

empresa_id = selected[0]
empresa = fetch(f"/api/empresas/{empresa_id}")

if not empresa:
    st.error("Empresa não encontrada.")
    st.stop()

# ─── Tabs ────────────────────────────────────────────────────────────
tab_resumo, tab_historico, tab_config = st.tabs(["📊 Resumo", "📜 Histórico", "⚙️ Configuração"])

# ─── Tab: Resumo ─────────────────────────────────────────────────────
with tab_resumo:
    c1, c2 = st.columns(2)

    with c1:
        st.markdown("#### Dados Cadastrais")
        st.markdown(f"""
        | Campo | Valor |
        |-------|-------|
        | **Razão Social** | {empresa.get('razao_social', '')} |
        | **CNPJ** | {empresa.get('cnpj', '')} |
        | **IE PR** | {empresa.get('inscricao_estadual_pr', '-') or '-'} |
        | **Email** | {empresa.get('email_notificacao', '-') or '-'} |
        | **WhatsApp** | {empresa.get('whatsapp', '-') or '-'} |
        | **Status** | {'✅ Ativa' if empresa.get('ativo') else '❌ Inativa'} |
        """)

    with c2:
        st.markdown("#### Agendamento")
        period_labels = {
            "diario": "Diário",
            "semanal": "Semanal",
            "quinzenal": "Quinzenal",
            "mensal": "Mensal",
        }
        day_names = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]
        dia_info = ""
        p = empresa.get("periodicidade", "")
        if p == "semanal" and empresa.get("dia_semana") is not None:
            dia_info = f" ({day_names[empresa['dia_semana']]})"
        elif p in ("quinzenal", "mensal") and empresa.get("dia_mes") is not None:
            dia_info = f" (dia {empresa['dia_mes']})"

        st.markdown(f"""
        | Campo | Valor |
        |-------|-------|
        | **Periodicidade** | {period_labels.get(p, p)}{dia_info} |
        | **Horário** | {empresa.get('horario', '08:00:00')} |
        | **Cadastrado em** | {(empresa.get('created_at', '') or '')[:10]} |
        | **Atualizado em** | {(empresa.get('updated_at', '') or '')[:10]} |
        """)

    # Latest results
    st.markdown("---")
    st.markdown("#### 🏷️ Últimos Resultados")
    for tipo, label in [("cnd_federal", "CND Federal"), ("cnd_pr", "CND PR"), ("fgts_regularidade", "FGTS")]:
        consultas = fetch("/api/consultas", {
            "empresa_id": empresa_id,
            "tipo": tipo,
            "limit": 1,
        })
        if consultas:
            c = consultas[0]
            situacao = c.get("situacao", "")
            status = c.get("status", "")
            emoji_map = {
                "positiva": "🟢", "negativa": "🔴", "regular": "🟢",
                "irregular": "🔴", "erro": "🟠",
            }
            emoji = emoji_map.get(situacao, "⚪")

            col1, col2, col3 = st.columns([2, 1, 1])
            with col1:
                st.markdown(f"**{label}**: {emoji} {(situacao or status).upper()}")
            with col2:
                data_exec = c.get("data_execucao", "")
                st.markdown(f"📅 {data_exec[:10] if data_exec else 'Pendente'}")
            with col3:
                pdf = c.get("pdf_url")
                if pdf:
                    st.markdown(f"[📄 Download PDF]({pdf})")
        else:
            st.markdown(f"**{label}**: ⚪ Sem consultas")

    # Force query button
    st.markdown("---")
    if st.button("🔄 Forçar Nova Consulta", key="force_detail"):
        result = post(f"/api/empresas/{empresa_id}/force-query", {
            "tipos": ["cnd_federal", "cnd_pr"]
        })
        if result:
            st.success(result.get("message", "Consulta agendada!"))
            st.rerun()

# ─── Tab: Histórico ──────────────────────────────────────────────────
with tab_historico:
    st.markdown("#### 📜 Histórico de Consultas")

    col_f1, col_f2 = st.columns(2)
    with col_f1:
        tipo_filter = st.selectbox(
            "Tipo",
            ["Todos", "cnd_federal", "cnd_pr", "fgts_regularidade"],
            key="hist_tipo",
        )
    with col_f2:
        status_filter = st.selectbox(
            "Status",
            ["Todos", "agendada", "processando", "concluida", "erro"],
            key="hist_status",
        )

    params = {"empresa_id": empresa_id, "limit": 50}
    if tipo_filter != "Todos":
        params["tipo"] = tipo_filter
    if status_filter != "Todos":
        params["status"] = status_filter

    consultas = fetch("/api/consultas", params)

    if consultas:
        df = pd.DataFrame(consultas)

        tipo_labels = {
            "cnd_federal": "CND Federal",
            "cnd_pr": "CND PR",
            "fgts_regularidade": "FGTS",
        }
        status_emojis = {
            "agendada": "🔵 Agendada",
            "processando": "🟡 Processando",
            "concluida": "🟢 Concluída",
            "erro": "🔴 Erro",
        }
        situacao_emojis = {
            "positiva": "🟢 Positiva",
            "negativa": "🔴 Negativa",
            "regular": "🟢 Regular",
            "irregular": "🔴 Irregular",
            "erro": "🟠 Erro",
        }

        df["Tipo"] = df["tipo"].map(tipo_labels).fillna(df["tipo"])
        df["Status"] = df["status"].map(status_emojis).fillna(df["status"])
        df["Situação"] = df["situacao"].map(situacao_emojis).fillna("—")
        df["Agendada"] = df["data_agendada"].apply(lambda x: x[:16] if x else "")
        df["Executada"] = df["data_execucao"].apply(lambda x: x[:16] if x else "—")
        df["Tentativas"] = df["tentativas"]

        display_df = df[["Tipo", "Status", "Situação", "Agendada", "Executada", "Tentativas"]]
        st.dataframe(display_df, use_container_width=True, hide_index=True)

        # PDF download links
        pdfs = df[df["pdf_url"].notna() & (df["pdf_url"] != "")]
        if not pdfs.empty:
            st.markdown("#### 📄 PDFs Disponíveis")
            for _, row in pdfs.iterrows():
                st.markdown(
                    f"- [{row['Tipo']} — {row['Executada']}]({row['pdf_url']})"
                )
    else:
        st.info("Nenhuma consulta registrada para esta empresa.")

# ─── Tab: Configuração ───────────────────────────────────────────────
with tab_config:
    st.markdown("#### ⚙️ Editar Configuração")

    with st.form("edit_config"):
        c1, c2 = st.columns(2)
        with c1:
            new_email = st.text_input(
                "Email para Notificação",
                value=empresa.get("email_notificacao", "") or "",
            )
            new_whatsapp = st.text_input(
                "WhatsApp",
                value=empresa.get("whatsapp", "") or "",
            )
            new_ie = st.text_input(
                "Inscrição Estadual PR",
                value=empresa.get("inscricao_estadual_pr", "") or "",
            )
        with c2:
            period_options = ["diario", "semanal", "quinzenal", "mensal"]
            current_period = empresa.get("periodicidade", "mensal")
            new_period = st.selectbox(
                "Periodicidade",
                period_options,
                index=period_options.index(current_period) if current_period in period_options else 3,
            )
            new_horario = st.text_input(
                "Horário (HH:MM:SS)",
                value=empresa.get("horario", "08:00:00"),
            )
            new_ativo = st.checkbox("Ativo", value=empresa.get("ativo", True))

        if st.form_submit_button("💾 Salvar Alterações"):
            update_data = {
                "email_notificacao": new_email or None,
                "whatsapp": new_whatsapp or None,
                "inscricao_estadual_pr": new_ie or None,
                "periodicidade": new_period,
                "horario": new_horario,
                "ativo": new_ativo,
            }
            result = put(f"/api/empresas/{empresa_id}", update_data)
            if result:
                st.success("✅ Configuração atualizada com sucesso!")
                st.rerun()
