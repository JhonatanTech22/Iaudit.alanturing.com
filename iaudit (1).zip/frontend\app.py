"""IAudit - Streamlit main application."""

import streamlit as st

st.set_page_config(
    page_title="IAudit — Automação Fiscal",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ──────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    .main .block-container {
        padding-top: 2rem;
        max-width: 1200px;
    }

    /* Sidebar */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
    }
    [data-testid="stSidebar"] .stMarkdown h1,
    [data-testid="stSidebar"] .stMarkdown h2,
    [data-testid="stSidebar"] .stMarkdown h3,
    [data-testid="stSidebar"] .stMarkdown p,
    [data-testid="stSidebar"] .stMarkdown span {
        color: #e2e8f0 !important;
    }

    /* KPI Cards */
    [data-testid="stMetric"] {
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        border: 1px solid #475569;
        border-radius: 12px;
        padding: 16px 20px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    [data-testid="stMetric"] label {
        color: #94a3b8 !important;
        font-size: 0.85rem !important;
    }
    [data-testid="stMetric"] [data-testid="stMetricValue"] {
        color: #f1f5f9 !important;
        font-weight: 700 !important;
    }

    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
        transform: translateY(-1px);
    }

    /* Tables */
    .stDataFrame {
        border-radius: 8px;
        overflow: hidden;
    }

    /* Alert badges */
    .badge-positiva { color: #22c55e; font-weight: 600; }
    .badge-negativa { color: #ef4444; font-weight: 600; }
    .badge-regular { color: #22c55e; font-weight: 600; }
    .badge-irregular { color: #ef4444; font-weight: 600; }
    .badge-processando { color: #eab308; font-weight: 600; }
    .badge-erro { color: #f97316; font-weight: 600; }
    .badge-agendada { color: #3b82f6; font-weight: 600; }

    /* Header */
    .iaudit-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
        padding: 1.5rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        border: 1px solid #1e3a5f;
    }
    .iaudit-header h1 {
        color: #60a5fa;
        margin: 0;
        font-size: 1.8rem;
    }
    .iaudit-header p {
        color: #94a3b8;
        margin: 0.3rem 0 0 0;
        font-size: 0.95rem;
    }
</style>
""", unsafe_allow_html=True)

# ─── Sidebar ─────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔍 IAudit")
    st.markdown("**Automação Fiscal**")
    st.markdown("---")
    st.markdown("### Navegação")
    st.markdown("""
    - 📊 **Dashboard**
    - 🏢 **Empresas**
    - 📤 **Upload**
    - 🔍 **Detalhes**
    """)
    st.markdown("---")
    st.markdown(
        "<small style='color:#64748b'>v1.0.0 • iaudit.allanturing.com</small>",
        unsafe_allow_html=True,
    )

# ─── Main Page ───────────────────────────────────────────────────────
st.markdown("""
<div class="iaudit-header">
    <h1>🔍 IAudit</h1>
    <p>Sistema de Automação Fiscal — Monitoramento de CND e FGTS</p>
</div>
""", unsafe_allow_html=True)

st.markdown("""
### Bem-vindo ao IAudit

Selecione uma página na barra lateral para começar:

| Página | Descrição |
|--------|-----------|
| 📊 **Dashboard** | KPIs, gráficos e alertas em tempo real |
| 🏢 **Empresas** | Gerenciar empresas cadastradas |
| 📤 **Upload** | Upload de CSV/Excel para cadastro em lote |
| 🔍 **Detalhes** | Histórico e configurações por empresa |
""")
