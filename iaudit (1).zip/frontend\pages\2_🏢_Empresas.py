"""IAudit - Empresas Management Page."""

import streamlit as st
import httpx
import pandas as pd
import os

st.set_page_config(page_title="IAudit — Empresas", page_icon="🏢", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")


def fetch(endpoint: str, params: dict | None = None):
    try:
        r = httpx.get(f"{BACKEND_URL}{endpoint}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro: {e}")
        return None


def post(endpoint: str, json_data: dict | None = None):
    try:
        r = httpx.post(f"{BACKEND_URL}{endpoint}", json=json_data, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro: {e}")
        return None


def put(endpoint: str, json_data: dict):
    try:
        r = httpx.put(f"{BACKEND_URL}{endpoint}", json=json_data, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro: {e}")
        return None


def delete(endpoint: str):
    try:
        r = httpx.delete(f"{BACKEND_URL}{endpoint}", timeout=10)
        return r.status_code == 204
    except Exception as e:
        st.error(f"Erro: {e}")
        return False


# ─── Header ──────────────────────────────────────────────────────────
st.markdown("""
<div style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
            padding: 1.5rem 2rem; border-radius: 12px; margin-bottom: 1.5rem;
            border: 1px solid #1e3a5f;">
    <h1 style="color: #60a5fa; margin: 0; font-size: 1.8rem;">🏢 Empresas</h1>
    <p style="color: #94a3b8; margin: 0.3rem 0 0 0;">Gerenciamento de empresas cadastradas</p>
</div>
""", unsafe_allow_html=True)

# ─── Filters ─────────────────────────────────────────────────────────
col_f1, col_f2, col_f3 = st.columns([2, 1, 1])
with col_f1:
    search = st.text_input("🔍 Buscar por CNPJ ou Razão Social", key="search")
with col_f2:
    status_filter = st.selectbox("Status", ["Todas", "Ativas", "Inativas"])
with col_f3:
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("➕ Nova Empresa"):
        st.session_state.show_add_form = True

# ─── Add Empresa Form ────────────────────────────────────────────────
if st.session_state.get("show_add_form"):
    with st.expander("➕ Cadastrar Nova Empresa", expanded=True):
        with st.form("add_empresa"):
            c1, c2 = st.columns(2)
            with c1:
                cnpj = st.text_input("CNPJ *")
                razao = st.text_input("Razão Social *")
                ie = st.text_input("Inscrição Estadual PR")
            with c2:
                email = st.text_input("Email para Notificação")
                whatsapp = st.text_input("WhatsApp")
                period = st.selectbox(
                    "Periodicidade",
                    ["diario", "semanal", "quinzenal", "mensal"],
                    index=3,
                )
            c3, c4 = st.columns(2)
            with c3:
                horario = st.time_input("Horário", value=None)
                horario_str = horario.strftime("%H:%M:%S") if horario else "08:00:00"
            with c4:
                if period == "semanal":
                    dia_semana = st.selectbox(
                        "Dia da Semana",
                        options=list(range(7)),
                        format_func=lambda x: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"][x],
                    )
                elif period in ("quinzenal", "mensal"):
                    dia_mes = st.number_input("Dia do Mês", min_value=1, max_value=31, value=1)
                else:
                    dia_semana = None
                    dia_mes = None

            submitted = st.form_submit_button("💾 Salvar")
            if submitted:
                data = {
                    "cnpj": cnpj,
                    "razao_social": razao,
                    "inscricao_estadual_pr": ie or None,
                    "email_notificacao": email or None,
                    "whatsapp": whatsapp or None,
                    "periodicidade": period,
                    "horario": horario_str,
                }
                if period == "semanal":
                    data["dia_semana"] = dia_semana
                elif period in ("quinzenal", "mensal"):
                    data["dia_mes"] = dia_mes

                result = post("/api/empresas", data)
                if result:
                    st.success(f"✅ Empresa {razao} cadastrada com sucesso!")
                    st.session_state.show_add_form = False
                    st.rerun()

# ─── Empresas Table ──────────────────────────────────────────────────
ativo_filter = None
if status_filter == "Ativas":
    ativo_filter = True
elif status_filter == "Inativas":
    ativo_filter = False

params = {"limit": 200}
if ativo_filter is not None:
    params["ativo"] = ativo_filter
if search:
    params["search"] = search

empresas = fetch("/api/empresas", params)

if empresas:
    # Get latest consulta status for each empresa
    for emp in empresas:
        consultas = fetch(f"/api/consultas", {"empresa_id": emp["id"], "limit": 1})
        if consultas:
            latest = consultas[0]
            situacao = latest.get("situacao", "")
            status = latest.get("status", "")
            if status == "processando":
                emp["_status_emoji"] = "🟡 Processando"
            elif situacao in ("positiva", "regular"):
                emp["_status_emoji"] = "🟢 Positiva"
            elif situacao in ("negativa", "irregular"):
                emp["_status_emoji"] = "🔴 Negativa"
            elif situacao == "erro":
                emp["_status_emoji"] = "🟠 Erro"
            else:
                emp["_status_emoji"] = "⚪ Pendente"
        else:
            emp["_status_emoji"] = "⚪ Sem consultas"

    df = pd.DataFrame(empresas)
    display_cols = {
        "razao_social": "Razão Social",
        "cnpj": "CNPJ",
        "_status_emoji": "Status",
        "periodicidade": "Periodicidade",
        "ativo": "Ativo",
    }
    df_display = df[list(display_cols.keys())].rename(columns=display_cols)
    df_display["Ativo"] = df_display["Ativo"].map({True: "✅", False: "❌"})

    st.dataframe(df_display, use_container_width=True, hide_index=True)

    # ─── Actions per empresa ─────────────────────────────────────────
    st.markdown("### ⚡ Ações")
    selected_empresa = st.selectbox(
        "Selecione uma empresa",
        options=[(e["id"], f"{e['razao_social']} ({e['cnpj']})") for e in empresas],
        format_func=lambda x: x[1],
    )

    if selected_empresa:
        emp_id = selected_empresa[0]
        col_a1, col_a2, col_a3, col_a4 = st.columns(4)

        with col_a1:
            if st.button("🔄 Forçar Consulta"):
                result = post(f"/api/empresas/{emp_id}/force-query", {
                    "tipos": ["cnd_federal", "cnd_pr"]
                })
                if result:
                    st.success(result.get("message", "Consulta agendada!"))
                    st.rerun()

        with col_a2:
            emp_data = next((e for e in empresas if e["id"] == emp_id), None)
            is_active = emp_data.get("ativo", True) if emp_data else True
            label = "⏸️ Pausar" if is_active else "▶️ Ativar"
            if st.button(label):
                put(f"/api/empresas/{emp_id}", {"ativo": not is_active})
                st.rerun()

        with col_a3:
            if st.button("🔍 Ver Detalhes"):
                st.session_state.detail_empresa_id = emp_id
                st.switch_page("pages/4_🔍_Detalhes.py")

        with col_a4:
            if st.button("🗑️ Remover"):
                if delete(f"/api/empresas/{emp_id}"):
                    st.success("Empresa desativada.")
                    st.rerun()

else:
    st.info("Nenhuma empresa encontrada. Cadastre uma empresa ou faça upload de um CSV.")
