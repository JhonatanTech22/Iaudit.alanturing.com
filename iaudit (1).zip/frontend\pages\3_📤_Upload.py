"""IAudit - CSV/Excel Upload Page."""

import streamlit as st
import httpx
import pandas as pd
import io
import os
import re

st.set_page_config(page_title="IAudit — Upload", page_icon="📤", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")


def validate_cnpj_frontend(cnpj: str) -> bool:
    """Quick CNPJ validation (check digits) for preview."""
    cnpj = re.sub(r"\D", "", cnpj)
    if len(cnpj) != 14 or cnpj == cnpj[0] * 14:
        return False
    w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    s = sum(int(cnpj[i]) * w1[i] for i in range(12))
    r = s % 11
    d1 = 0 if r < 2 else 11 - r
    if int(cnpj[12]) != d1:
        return False
    w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    s = sum(int(cnpj[i]) * w2[i] for i in range(13))
    r = s % 11
    d2 = 0 if r < 2 else 11 - r
    return int(cnpj[13]) == d2


# ─── Header ──────────────────────────────────────────────────────────
st.markdown("""
<div style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
            padding: 1.5rem 2rem; border-radius: 12px; margin-bottom: 1.5rem;
            border: 1px solid #1e3a5f;">
    <h1 style="color: #60a5fa; margin: 0; font-size: 1.8rem;">📤 Upload de Empresas</h1>
    <p style="color: #94a3b8; margin: 0.3rem 0 0 0;">Cadastro em lote via CSV ou Excel</p>
</div>
""", unsafe_allow_html=True)

# ─── Instructions ────────────────────────────────────────────────────
with st.expander("📋 Formato do Arquivo", expanded=False):
    st.markdown("""
    O arquivo deve conter as seguintes colunas:

    | Coluna | Obrigatória | Descrição |
    |--------|:-----------:|-----------|
    | `cnpj` | ✅ | CNPJ da empresa (com ou sem formatação) |
    | `razao_social` | ✅ | Razão social da empresa |
    | `inscricao_estadual_pr` | ❌ | Inscrição Estadual do Paraná |
    | `email_notificacao` | ❌ | Email para receber alertas |
    | `whatsapp` | ❌ | WhatsApp para notificações |

    **Formatos aceitos:** `.csv`, `.xlsx`, `.xls`
    """)

    # Download template
    template_df = pd.DataFrame({
        "cnpj": ["11222333000181", "99888777000166"],
        "razao_social": ["Empresa Exemplo LTDA", "Empresa Teste SA"],
        "inscricao_estadual_pr": ["1234567890", ""],
        "email_notificacao": ["fiscal@exemplo.com", ""],
        "whatsapp": ["41999999999", ""],
    })
    csv_template = template_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "📥 Baixar Template CSV",
        csv_template,
        "template_iaudit.csv",
        "text/csv",
    )

# ─── Upload ──────────────────────────────────────────────────────────
st.markdown("### 📁 Selecione o Arquivo")

uploaded_file = st.file_uploader(
    "Arraste ou selecione um arquivo CSV/Excel",
    type=["csv", "xlsx", "xls"],
    help="Formatos aceitos: CSV, XLSX, XLS",
)

if uploaded_file:
    # Read file
    try:
        content = uploaded_file.read()
        if uploaded_file.name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(content))
        else:
            for enc in ["utf-8", "latin-1", "cp1252"]:
                try:
                    df = pd.read_csv(io.BytesIO(content), encoding=enc)
                    break
                except UnicodeDecodeError:
                    continue

        df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

        if "cnpj" not in df.columns or "razao_social" not in df.columns:
            st.error("❌ O arquivo deve conter as colunas `cnpj` e `razao_social`.")
        else:
            # Validate CNPJs
            df["cnpj_limpo"] = df["cnpj"].astype(str).apply(lambda x: re.sub(r"\D", "", x))
            df["cnpj_valido"] = df["cnpj_limpo"].apply(validate_cnpj_frontend)
            df["status_validacao"] = df["cnpj_valido"].map({
                True: "✅ Válido",
                False: "❌ Inválido"
            })

            # Preview
            st.markdown(f"### 👁️ Preview — {len(df)} empresa(s) encontrada(s)")

            valid_count = df["cnpj_valido"].sum()
            invalid_count = len(df) - valid_count

            c1, c2, c3 = st.columns(3)
            with c1:
                st.metric("Total", len(df))
            with c2:
                st.metric("✅ Válidos", int(valid_count))
            with c3:
                st.metric("❌ Inválidos", int(invalid_count))

            # Show preview table
            preview_cols = ["cnpj", "razao_social", "status_validacao"]
            for col in ["inscricao_estadual_pr", "email_notificacao", "whatsapp"]:
                if col in df.columns:
                    preview_cols.insert(-1, col)

            st.dataframe(
                df[preview_cols].rename(columns={
                    "cnpj": "CNPJ",
                    "razao_social": "Razão Social",
                    "inscricao_estadual_pr": "IE PR",
                    "email_notificacao": "Email",
                    "whatsapp": "WhatsApp",
                    "status_validacao": "Validação",
                }),
                use_container_width=True,
                hide_index=True,
            )

            # Scheduling config
            st.markdown("### ⚙️ Configuração de Agendamento")
            c1, c2 = st.columns(2)
            with c1:
                periodicidade = st.selectbox(
                    "Periodicidade",
                    ["diario", "semanal", "quinzenal", "mensal"],
                    index=3,
                )
            with c2:
                horario = st.time_input("Horário das Consultas", value=None)
                horario_str = horario.strftime("%H:%M:%S") if horario else "08:00:00"

            # Submit
            st.markdown("---")
            if st.button("🚀 Enviar e Cadastrar Empresas", type="primary"):
                with st.spinner("Processando upload..."):
                    try:
                        uploaded_file.seek(0)
                        files = {"file": (uploaded_file.name, uploaded_file.read(), uploaded_file.type)}
                        params = {
                            "periodicidade": periodicidade,
                            "horario": horario_str,
                        }
                        r = httpx.post(
                            f"{BACKEND_URL}/api/empresas/upload",
                            files=files,
                            params=params,
                            timeout=60,
                        )
                        r.raise_for_status()
                        result = r.json()

                        st.markdown("### 📊 Resultado do Upload")
                        r1, r2, r3, r4 = st.columns(4)
                        with r1:
                            st.metric("Total", result.get("total", 0))
                        with r2:
                            st.metric("✅ Criadas", result.get("criadas", 0))
                        with r3:
                            st.metric("🔄 Duplicadas", result.get("duplicadas", 0))
                        with r4:
                            st.metric("❌ Inválidas", result.get("invalidas", 0))

                        erros = result.get("erros", [])
                        if erros:
                            with st.expander(f"⚠️ {len(erros)} erro(s) encontrado(s)"):
                                for erro in erros:
                                    st.text(erro)

                        if result.get("criadas", 0) > 0:
                            st.success(
                                f"✅ {result['criadas']} empresa(s) cadastrada(s) com sucesso!"
                            )
                            st.balloons()

                    except Exception as e:
                        st.error(f"❌ Erro no upload: {e}")

    except Exception as e:
        st.error(f"❌ Erro ao ler arquivo: {e}")
