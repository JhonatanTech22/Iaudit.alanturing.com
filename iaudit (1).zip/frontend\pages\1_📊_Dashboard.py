"""IAudit - Dashboard Page."""

import streamlit as st
import httpx
import os
import sys

# Add parent dir to path for components import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from components.charts import create_bar_chart

st.set_page_config(page_title="IAudit — Dashboard", page_icon="📊", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")


def fetch(endpoint: str, params: dict | None = None):
    """Fetch data from backend API."""
    try:
        r = httpx.get(f"{BACKEND_URL}{endpoint}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Erro ao conectar ao backend: {e}")
        return None


# ─── Header ──────────────────────────────────────────────────────────
st.markdown("""
<div style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%);
            padding: 1.5rem 2rem; border-radius: 12px; margin-bottom: 1.5rem;
            border: 1px solid #1e3a5f;">
    <h1 style="color: #60a5fa; margin: 0; font-size: 1.8rem;">📊 Dashboard</h1>
    <p style="color: #94a3b8; margin: 0.3rem 0 0 0;">Visão geral do monitoramento fiscal</p>
</div>
""", unsafe_allow_html=True)

# ─── KPI Cards ───────────────────────────────────────────────────────
stats = fetch("/api/dashboard/stats")

if stats:
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("🏢 Empresas Ativas", stats.get("empresas_ativas", 0))
    with c2:
        st.metric("📋 Consultas Hoje", stats.get("consultas_hoje", 0))
    with c3:
        st.metric("🚨 Alertas Ativos", stats.get("alertas_ativos", 0))
    with c4:
        st.metric("✅ Taxa de Sucesso", f"{stats.get('taxa_sucesso', 0)}%")

st.markdown("---")

# ─── Chart + Alerts side by side ─────────────────────────────────────
col_chart, col_alerts = st.columns([3, 2])

with col_chart:
    st.markdown("### 📈 Consultas nos Últimos 7 Dias")
    chart_data = fetch("/api/dashboard/chart", {"dias": 7})
    if chart_data:
        fig = create_bar_chart(chart_data)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Nenhum dado de consulta encontrado.")

with col_alerts:
    st.markdown("### 🚨 Alertas Recentes")
    alerts = fetch("/api/dashboard/alerts", {"limite": 10})
    if alerts:
        for alert in alerts:
            situacao = alert.get("situacao", "")
            emoji = "🔴" if situacao in ("negativa", "irregular") else "🟡"
            tipo_labels = {
                "cnd_federal": "CND Federal",
                "cnd_pr": "CND PR",
                "fgts_regularidade": "FGTS",
            }
            tipo = tipo_labels.get(alert.get("tipo", ""), alert.get("tipo", ""))

            st.markdown(
                f"""<div style="background: #1e293b; border-radius: 8px; padding: 10px 14px;
                        margin-bottom: 8px; border-left: 4px solid {'#ef4444' if situacao in ('negativa', 'irregular') else '#f97316'};">
                    <strong style="color: #f1f5f9;">{emoji} {alert.get('razao_social', '')}</strong><br>
                    <span style="color: #94a3b8; font-size: 0.85rem;">
                        {tipo} • {situacao.upper()} • {alert.get('data_execucao', '')[:10]}
                    </span>
                </div>""",
                unsafe_allow_html=True,
            )
    else:
        st.success("✅ Nenhum alerta ativo. Tudo em ordem!")

# ─── Upcoming Queries ────────────────────────────────────────────────
st.markdown("---")
st.markdown("### ⏰ Próximas Consultas Agendadas")

upcoming = fetch("/api/dashboard/upcoming", {"limite": 10})
if upcoming:
    import pandas as pd

    df = pd.DataFrame(upcoming)
    tipo_labels = {
        "cnd_federal": "CND Federal",
        "cnd_pr": "CND PR",
        "fgts_regularidade": "FGTS",
    }
    df["tipo"] = df["tipo"].map(tipo_labels).fillna(df["tipo"])
    df = df.rename(columns={
        "razao_social": "Empresa",
        "cnpj": "CNPJ",
        "tipo": "Tipo",
        "data_agendada": "Agendada para",
    })
    st.dataframe(
        df[["Empresa", "CNPJ", "Tipo", "Agendada para"]],
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("Nenhuma consulta agendada no momento.")

# ─── Auto-refresh ────────────────────────────────────────────────────
st.markdown("---")
col_r1, col_r2 = st.columns([1, 4])
with col_r1:
    if st.button("🔄 Atualizar"):
        st.rerun()
with col_r2:
    st.markdown(
        "<small style='color:#64748b'>Auto-atualização: use o botão acima ou recarregue a página.</small>",
        unsafe_allow_html=True,
    )

# Auto-refresh every 60 seconds
import time
# Use st.empty() for a countdown-based approach
if "auto_refresh" not in st.session_state:
    st.session_state.auto_refresh = True

if st.session_state.auto_refresh:
    time.sleep(60)
    st.rerun()
