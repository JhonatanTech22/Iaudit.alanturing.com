"""IAudit - Supabase database client wrapper."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from supabase import create_client, Client

from app.config import settings

logger = logging.getLogger(__name__)

_client: Client | None = None


def get_supabase() -> Client:
    """Get or create the Supabase client singleton."""
    global _client
    if _client is None:
        _client = create_client(settings.supabase_url, settings.supabase_key)
    return _client


# ─── Empresas ────────────────────────────────────────────────────────

def get_empresas(
    ativo: bool | None = None,
    search: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict]:
    """List empresas with optional filters."""
    sb = get_supabase()
    query = sb.table("empresas").select("*")
    if ativo is not None:
        query = query.eq("ativo", ativo)
    if search:
        query = query.or_(f"cnpj.ilike.%{search}%,razao_social.ilike.%{search}%")
    query = query.order("razao_social").range(offset, offset + limit - 1)
    return query.execute().data


def get_empresa_by_id(empresa_id: str) -> dict | None:
    """Get a single empresa by ID."""
    sb = get_supabase()
    result = sb.table("empresas").select("*").eq("id", empresa_id).execute()
    return result.data[0] if result.data else None


def get_empresa_by_cnpj(cnpj: str) -> dict | None:
    """Get a single empresa by CNPJ."""
    sb = get_supabase()
    result = sb.table("empresas").select("*").eq("cnpj", cnpj).execute()
    return result.data[0] if result.data else None


def create_empresa(data: dict) -> dict:
    """Insert a new empresa."""
    sb = get_supabase()
    result = sb.table("empresas").insert(data).execute()
    return result.data[0]


def update_empresa(empresa_id: str, data: dict) -> dict:
    """Update an empresa."""
    sb = get_supabase()
    result = sb.table("empresas").update(data).eq("id", empresa_id).execute()
    return result.data[0]


def delete_empresa(empresa_id: str) -> None:
    """Soft-delete (deactivate) an empresa."""
    sb = get_supabase()
    sb.table("empresas").update({"ativo": False}).eq("id", empresa_id).execute()


def get_empresas_ativas() -> list[dict]:
    """Get all active empresas for scheduling."""
    sb = get_supabase()
    return sb.table("empresas").select("*").eq("ativo", True).execute().data


def count_empresas(ativo: bool | None = None) -> int:
    """Count empresas."""
    sb = get_supabase()
    query = sb.table("empresas").select("id", count="exact")
    if ativo is not None:
        query = query.eq("ativo", ativo)
    result = query.execute()
    return result.count or 0


# ─── Consultas ───────────────────────────────────────────────────────

def get_consultas_pendentes() -> list[dict]:
    """Get scheduled consultas that are due for execution."""
    sb = get_supabase()
    now = datetime.now(timezone.utc).isoformat()
    return (
        sb.table("consultas")
        .select("*, empresas(cnpj, razao_social, inscricao_estadual_pr, email_notificacao)")
        .eq("status", "agendada")
        .lte("data_agendada", now)
        .order("data_agendada")
        .execute()
        .data
    )


def get_consultas_retry() -> list[dict]:
    """Get failed consultas that can still be retried."""
    sb = get_supabase()
    return (
        sb.table("consultas")
        .select("*, empresas(cnpj, razao_social, inscricao_estadual_pr, email_notificacao)")
        .eq("status", "erro")
        .lt("tentativas", settings.max_retries)
        .order("data_agendada")
        .execute()
        .data
    )


def create_consulta(data: dict) -> dict:
    """Insert a new consulta."""
    sb = get_supabase()
    result = sb.table("consultas").insert(data).execute()
    return result.data[0]


def update_consulta(consulta_id: str, data: dict) -> dict:
    """Update a consulta record."""
    sb = get_supabase()
    result = sb.table("consultas").update(data).eq("id", consulta_id).execute()
    return result.data[0]


def get_consultas(
    empresa_id: str | None = None,
    tipo: str | None = None,
    status: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    """List consultas with filters."""
    sb = get_supabase()
    query = sb.table("consultas").select("*, empresas(cnpj, razao_social)")
    if empresa_id:
        query = query.eq("empresa_id", empresa_id)
    if tipo:
        query = query.eq("tipo", tipo)
    if status:
        query = query.eq("status", status)
    query = query.order("data_agendada", desc=True).range(offset, offset + limit - 1)
    return query.execute().data


def get_consulta_by_id(consulta_id: str) -> dict | None:
    """Get a single consulta by ID."""
    sb = get_supabase()
    result = (
        sb.table("consultas")
        .select("*, empresas(cnpj, razao_social)")
        .eq("id", consulta_id)
        .execute()
    )
    return result.data[0] if result.data else None


def count_consultas_hoje() -> int:
    """Count consultas executed today."""
    sb = get_supabase()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    result = (
        sb.table("consultas")
        .select("id", count="exact")
        .gte("data_execucao", f"{today}T00:00:00Z")
        .execute()
    )
    return result.count or 0


def count_alertas_ativos() -> int:
    """Count active alerts (negativa / irregular)."""
    sb = get_supabase()
    result = (
        sb.table("consultas")
        .select("id", count="exact")
        .eq("status", "concluida")
        .in_("situacao", ["negativa", "irregular"])
        .execute()
    )
    return result.count or 0


# ─── Logs ────────────────────────────────────────────────────────────

def create_log(consulta_id: str, nivel: str, mensagem: str, payload: Any = None):
    """Insert an execution log entry."""
    sb = get_supabase()
    data = {
        "consulta_id": consulta_id,
        "nivel": nivel,
        "mensagem": mensagem,
    }
    if payload:
        data["payload"] = payload
    sb.table("logs_execucao").insert(data).execute()


# ─── RPC calls ───────────────────────────────────────────────────────

def rpc_consultas_por_dia(dias: int = 7) -> list[dict]:
    """Call the consultas_por_dia Supabase function."""
    sb = get_supabase()
    return sb.rpc("consultas_por_dia", {"dias": dias}).execute().data


def rpc_proximas_consultas(limite: int = 10) -> list[dict]:
    """Call the proximas_consultas Supabase function."""
    sb = get_supabase()
    return sb.rpc("proximas_consultas", {"limite": limite}).execute().data


def rpc_alertas_ativos(limite: int = 20) -> list[dict]:
    """Call the alertas_ativos Supabase function."""
    sb = get_supabase()
    return sb.rpc("alertas_ativos", {"limite": limite}).execute().data
