"""IAudit - Plotly chart components."""

from __future__ import annotations

import plotly.graph_objects as go


def create_bar_chart(chart_data: list[dict]) -> go.Figure:
    """
    Create a styled bar chart showing queries per day.

    Args:
        chart_data: List of dicts with keys: data, total, sucessos, erros
    """
    dates = [d.get("data", "") for d in chart_data]
    sucessos = [d.get("sucessos", 0) for d in chart_data]
    erros = [d.get("erros", 0) for d in chart_data]

    fig = go.Figure()

    fig.add_trace(go.Bar(
        name="Sucesso",
        x=dates,
        y=sucessos,
        marker_color="#22c55e",
        marker_line_width=0,
        opacity=0.9,
    ))

    fig.add_trace(go.Bar(
        name="Erro",
        x=dates,
        y=erros,
        marker_color="#ef4444",
        marker_line_width=0,
        opacity=0.9,
    ))

    fig.update_layout(
        barmode="stack",
        plot_bgcolor="rgba(15,23,42,0.8)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", family="Inter"),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
            font=dict(size=12),
        ),
        margin=dict(l=40, r=20, t=40, b=40),
        height=320,
        xaxis=dict(
            title="Data",
            gridcolor="rgba(71,85,105,0.3)",
            tickfont=dict(size=11),
        ),
        yaxis=dict(
            title="Consultas",
            gridcolor="rgba(71,85,105,0.3)",
            tickfont=dict(size=11),
        ),
    )

    return fig


def create_donut_chart(positivas: int, negativas: int, erros: int) -> go.Figure:
    """Create a donut chart for consultation status distribution."""
    labels = ["Positiva/Regular", "Negativa/Irregular", "Erro"]
    values = [positivas, negativas, erros]
    colors = ["#22c55e", "#ef4444", "#f97316"]

    fig = go.Figure(data=[go.Pie(
        labels=labels,
        values=values,
        hole=0.5,
        marker=dict(colors=colors, line=dict(color="#1e293b", width=2)),
        textfont=dict(color="#e2e8f0", size=12),
    )])

    fig.update_layout(
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", family="Inter"),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.15,
            xanchor="center",
            x=0.5,
            font=dict(size=11),
        ),
        margin=dict(l=20, r=20, t=20, b=40),
        height=280,
    )

    return fig
